# capstone-project-GDDA7123C
Initial step to create my capstone project portfolio
